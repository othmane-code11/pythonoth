// theme
let themebuttons = document.querySelectorAll('.theme-btn');
let body = document.body;

themebuttons.forEach((button) => {
    button.addEventListener('click', () => {
        let theme = button.id.replace('-btn', '-theme');
        body.className = theme;
    });
});

// sections
let sections = document.querySelectorAll('.section');
function activeClasse(sec_id) {
    sections.forEach(section => {
        section.classList.toggle('active', section.id === sec_id);
    });
}
document.getElementById("showClients").addEventListener("click", () => activeClasse("clients"));
document.getElementById("showReservation").addEventListener("click", () => activeClasse("reservation"));
document.getElementById("showTickets").addEventListener("click", () => activeClasse("tickets"));

// gestion des client
let clientForm = document.getElementById('clientForm');
let clients = [];
let clientsTableBody = document.querySelector('#clientsTable tbody');

clientForm.addEventListener('submit', (e) => {
    e.preventDefault();
    let nomComplet = document.getElementById('nomComplet').value;
    let cin = document.getElementById('cin').value;
    let estEtudiant = document.querySelector('input[name="estEtudiant"]:checked').value === "true";

    if (clients.some(client => client.cin === cin)) {
        alert('cin doit etre unique');
        return;
    }

    let client = {nomComplet, cin, estEtudiant};
    clients.push(client);
    updateclientTable();
    updateclientSelect();
    clientForm.reset();
});

function updateclientTable() {
    clientsTableBody.innerHTML = "";
    clients.forEach((client, index) => {
        let row = document.createElement('tr');
        row.innerHTML = `
            <td>${client.nomComplet}</td>
            <td>${client.cin}</td>
            <td>${(client.estEtudiant) ? 'Oui' : 'Non'}</td>
            <td><button onclick="deleteClient(${index})">Supprimer</button></td>
        `;
        clientsTableBody.appendChild(row);
    });
}

function deleteClient(index) {
    if (confirm('Etes-vous sur?')) {
        clients.splice(index, 1);
        updateclientTable();
    }
}

let clientSelect = document.getElementById('clientSelect');
function updateclientSelect() {
    clientSelect.innerHTML = "";
    clients.forEach((client, index)  => {
        let opt = document.createElement('option');
        opt.value = index;
        opt.textContent = `${client.nomComplet} (${client.cin})`;
        clientSelect.appendChild(opt);
    });
}

let reservationForm = document.getElementById('reservationForm');
let ticketsTable = document.querySelector('#ticketsTable tbody');

reservationForm.addEventListener('submit', (e) => {
    e.preventDefault();

    let clientIndex = document.getElementById('clientSelect').selectedIndex;
    let destination = document.getElementById('destination').value;
    let classe = document.querySelector('input[name="classe"]:checked').value;

    let estEtudiant = clients[clientIndex].estEtudiant;

    let prixdest = {
        rabat : 40,
        mohammedia : 20,
        marrakech : 150,
        tanger : 290
    };

    let prixd = prixdest[destination];
    let prixfinal = prixd * (classe === "1" ? 1.5 : 1) * (estEtudiant ? 0.7 : 1);

    document.getElementById('totalPrice').textContent = `Le prix est ${prixfinal.toFixed(2)} DH`;

    let d = new Date;
    let dformat = [d.getDate(), d.getMonth()+1, d.getFullYear()].join('/') + ' ' + [d.getHours(), d.getMinutes(), d.getSeconds()].join(':');

    let ticket = {
        client : clients[clientIndex],
        destination,
        classe,
        prix : prixfinal.toFixed(2),
        date : dformat
    };
    updateTicketsTable (ticket);
});
function updateTicketsTable (ticket) {
    let row = document.createElement('tr');
    row.innerHTML = `
        <td>${ticket.client.nomComplet} (${ticket.client.cin.slice(0, 3)}...)</td>
        <td>${ticket.client.estEtudiant ? 'Oui' : 'Non'}</td>
        <td>${ticket.destination}</td>
        <td>${ticket.classe}</td>
        <td>${ticket.prix}</td>
        <td>${ticket.date}</td>
    `;
    ticketsTable.appendChild(row);
}