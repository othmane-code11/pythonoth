// exercice 1
console.log("Bonjour, monde !");
let nom = 'othmane';
alert(`Bonjour, ${nom}!`);