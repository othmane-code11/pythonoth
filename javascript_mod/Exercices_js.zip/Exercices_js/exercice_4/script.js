let contenu = document.getElementById('contenu');
contenu.textContent = "Bienvenue sur ma page web !";
contenu.style.color = 'blue';
contenu.style.border = 'red solid 2px'